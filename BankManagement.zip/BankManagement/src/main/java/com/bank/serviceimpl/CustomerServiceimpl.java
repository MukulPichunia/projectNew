package com.bank.serviceimpl;

import java.util.List;

import org.springframework.stereotype.Service;

import com.bank.entity.CustomerEntity;
import com.bank.CustomerRepository.CustomerRepository;
import com.bank.service.CustomerService;

@Service
public class CustomerServiceimpl implements CustomerService{

	private CustomerRepository customerRepository;
	
	public CustomerServiceimpl(CustomerRepository customerRepository) {
		super();
		this.customerRepository = customerRepository;
	}

	@Override
	public List<CustomerEntity> getAllCustomers() {

		return customerRepository.findAll();
	}

	@Override
	public CustomerEntity saveCustomer(CustomerEntity customer) {
		return customerRepository.save(customer);
	}

	@Override
	public CustomerEntity getCustomerById(Long id) {
		return customerRepository.findById(id).get();
	}
	@Override
	public CustomerEntity updateCustomer(CustomerEntity customer) {
		return customerRepository.save(customer);
	}

	@Override
	public void deleteCustomerById(Long id) {
		customerRepository.deleteById(id);
	}

	public CustomerEntity depositCustomerById(Long id){
		return customerRepository.findById(id).get();
	}

}